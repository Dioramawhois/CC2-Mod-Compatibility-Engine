Copy announcement-en.txt into your chat or group and attach the four PNGs in numerical order.
These are actual application captures from an isolated demonstration workspace.
The Example patches deliberately overlap to show the warning; no gameplay acceptance is implied.
Detailed provenance: https://github.com/Dioramawhois/CC2-ModLoader/blob/main/docs/SCREENSHOTS.md
